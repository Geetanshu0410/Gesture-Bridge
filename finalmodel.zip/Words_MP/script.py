try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Masking, LSTM, Dropout, Dense
    from tensorflow.keras.callbacks import EarlyStopping

    print("✅ TensorFlow and all specified modules are available.")
except ImportError as e:
    print(f"❌ Import failed: {e}")
