# Great! I’ll create a CPU‑optimized Python training script that:

# - Loads your dynamic landmark CSV files from D:/ROBOFLOWLSTMYOLO
# - Trains an LSTM model with Masking(mask_value=0.0) to ignore padding
# - Also evaluates classical ML models (SVC, XGBoost, etc.) side-by-side
# - Outputs performance metrics (Accuracy, Precision, Recall, F1)
# - Saves both .h5 (LSTM) and .pkl (best classical model) files

# This script will include tqdm progress bars, handle label encoding, and ensure fast execution on a CPU (~10–15 minutes max).

# I’ll get started and deliver the .py file for VS Code shortly!

# # Hand Gesture Recognition: LSTM and Classical Models Training Script

# In this solution, we create a Python script to train a hand gesture recognition model using both a deep learning approach (LSTM) and six classical machine learning classifiers. The script will load flattened hand landmark sequences from CSV files, preprocess the data, build and train an LSTM model (with appropriate masking and regularization), and also train classical algorithms (Logistic Regression, Decision Tree, Random Forest, SVC, KNN, XGBoost). We ensure labels are encoded consistently across datasets using a LabelEncoder ([3 Ways to Encode Categorical Variables for Deep Learning - MachineLearningMastery.com](https://machinelearningmastery.com/how-to-prepare-categorical-data-for-deep-learning-in-python/#::text=The%20best%20practice%20when%20encoding,the%20train%20and%20test%20datasets)). All models are evaluated on a held-out test set using accuracy, precision, recall, and F1-score (macro-averaged). The macro-averaged F1 score, which is the unweighted mean of per-class F1 scores ([  Micro, Macro & Weighted Averages of F1 Score, Clearly Explained - KDnuggets](https://www.kdnuggets.com/2023/01/micro-macro-weighted-averages-f1-score-clearly-explained.html#::text=The%20macro,class%20F1%20scores)), is used to identify the best-performing model. The script is optimized for a CPU-only environment by using a small batch size, the EarlyStopping callback (to halt training when validation performance stops improving) ([Overfit and underfit  |  TensorFlow Core](https://www.tensorflow.org/tutorials/keras/overfit_and_underfit#:~:text=Next%20include%20tf,difference%20will%20be%20important%20later)), and progress bars via tqdm for longer training loops ([TensorFlow Addons Callbacks: TQDM Progress Bar](https://www.tensorflow.org/addons/tutorials/tqdm_progress_bar#:~:text=Default%20TQDMCallback%20Usage)). We include clear comments for each step, and configuration constants at the top for easy path adjustments. The best model (based on macro-F1) is saved as a pickle file, alongside the trained label encoder and the LSTM model saved in HDF5 format.

# ## Data Loading and Preprocessing

# We assume the dataset is provided as three CSV files (train_seq.csv, valid_seq.csv, test_seq.csv) in a directory D:/ROBOFLOWLSTMYOLO. Each CSV has 1680 feature columns (representing 40 frames of flattened hand landmark coordinates) and a label column. We define configuration paths at the top of the script for easy modification. The script uses pandas to load the data, then separates features and labels. Labels are encoded into numeric form using scikit-learn’s LabelEncoder, which is fit on the training set labels and applied to validation and test labels to ensure a consistent mapping ([3 Ways to Encode Categorical Variables for Deep Learning - MachineLearningMastery.com](https://machinelearningmastery.com/how-to-prepare-categorical-data-for-deep-learning-in-python/#::text=The%20best%20practice%20when%20encoding,the%20train%20and%20test%20datasets)). The 1680-dim feature vectors are reshaped into sequences of shape (40 timesteps, 42 features per timestep) for input to the LSTM model. We rely on the fact that sequences may be padded with zeros to reach 40 frames; using 0.0 as the pad value will allow the LSTM’s Masking layer to ignore those padded timesteps ([Masking layer](https://keras.io/api/layers/core_layers/masking/#::text=Masks%20a%20sequence%20by%20using,mask%20value%20to%20skip%20timesteps)).

# ## LSTM Model Construction and Training

# The script builds a Keras Sequential model for the LSTM-based classifier. We add a Masking layer with mask_value=0.0 as the first layer, so any timestep consisting entirely of 0.0 values is skipped by subsequent layers ([Masking layer](https://keras.io/api/layers/core_layers/masking/#:~:text=Masks%20a%20sequence%20by%20using,mask%20value%20to%20skip%20timesteps)). This ensures that padded frames (which are all-zero vectors) do not contribute to learning. Next, we add an LSTM layer (with a moderate number of units, e.g. 64) and a Dropout layer. Dropout randomly drops a fraction of units during training, which forces the network to not rely on any single feature and thus helps prevent overfitting ([  5 Techniques to Prevent Overfitting in Neural Networks - KDnuggets](https://www.kdnuggets.com/2019/12/5-techniques-prevent-overfitting-neural-networks.html#::text=Dropout%20is%20a%20regularization%20technique,and%20L2%20reduce%20overfitting%20by)) ([  5 Techniques to Prevent Overfitting in Neural Networks - KDnuggets](https://www.kdnuggets.com/2019/12/5-techniques-prevent-overfitting-neural-networks.html#::text=different%20ways%2C%20so%20the%20net,will%20be%20to%20reduce%20overfitting)). Finally, a Dense output layer with softmax activation produces class probabilities for each of the gesture classes.

# We compile the model with the Adam optimizer and use sparse_categorical_crossentropy loss since our labels are integer-encoded. Training is done on the training set with validation on the validation set. We use a small batch size (e.g. 32) to reduce memory usage on CPU. We also employ EarlyStopping (monitoring validation loss) with patience of a few epochs to stop training when the model’s validation performance stops improving, thereby avoiding unnecessary epochs and potential overfitting ([Overfit and underfit  |  TensorFlow Core](https://www.tensorflow.org/tutorials/keras/overfit_and_underfit#:~:text=Next%20include%20tf,difference%20will%20be%20important%20later)). The best weights are restored at the end of training. A tqdm progress bar callback is integrated into the training loop to provide a live indication of training progress per epoch ([TensorFlow Addons Callbacks: TQDM Progress Bar](https://www.tensorflow.org/addons/tutorials/tqdm_progress_bar#:~:text=Default%20TQDMCallback%20Usage)).

# ## Classical Machine Learning Models

# In addition to the LSTM, we train six traditional classifiers using the flattened sequence features: Logistic Regression, Decision Tree, Random Forest, Support Vector Classifier (SVC), K-Nearest Neighbors, and XGBoost. These models are trained on the same training data (with 1680 features per sample) after label encoding. We configure these models with basic settings:
# - *Logistic Regression:* using a solver like 'lbfgs' with a higher max_iter to ensure convergence for multi-class data.
# - *Decision Tree:* using default settings (could limit depth to prevent overfitting, but we use default for simplicity).
# - *Random Forest:* using a reasonable number of trees (e.g. 100).
# - *Support Vector Classifier:* using a linear kernel for speed, since a non-linear (RBF) SVM on 80 classes would be very slow on CPU (scikit-learn’s SVC defaults to one-vs-one classification, which would train $\binom{80}{2}$ binary SVMs). The linear kernel (one-vs-rest strategy) makes training feasible within our time budget.
# - *K-Nearest Neighbors:* using a default of k=5.
# - *XGBoost:* using the XGBClassifier with default parameters (which will do multi-class classification via softmax). We assume xgboost is installed; if not, the script can be adjusted to skip or install it.

# We iterate over these models with a progress bar so the user can see training progress for each. For models that support it, training is typically fast enough on CPU given our dataset size (~14k samples, 1680 features).

# ## Model Evaluation and Comparison

# After training, each model (including the LSTM) is evaluated on the test set. We obtain predictions and compute *Accuracy, **Precision, **Recall, and **F1-score* for each model. For the latter three metrics, we use macro-averaging to treat all classes equally regardless of frequency ([  Micro, Macro & Weighted Averages of F1 Score, Clearly Explained - KDnuggets](https://www.kdnuggets.com/2023/01/micro-macro-weighted-averages-f1-score-clearly-explained.html#:~:text=The%20macro,class%20F1%20scores)), which is appropriate in multi-class settings. A summary table is printed to compare the models' performance. Each row lists the model name and its Accuracy, Precision (macro), Recall (macro), and F1-score (macro). This provides a clear comparison of how the deep learning model fares against classical methods.

# ## Saving the Best Model and Artifacts

# Finally, the script identifies which model achieved the highest macro F1-score on the test data. That model is deemed the "best" and is saved to disk as best_model.pkl using Python’s pickle. (Scikit-learn models are generally pickle-able for persistence ([9. Model persistence — scikit-learn 1.4.2 documentation](https://scikit-learn.org/1.4/model_persistence.html#:~:text=9.%20Model%20persistence%20%E2%80%94%20scikit,in%20persistence%20model%2C%20namely%20pickle)). For the Keras LSTM model, we will save it separately in HDF5 format, as Keras models are typically saved using model.save() rather than pickling.) We also save the LabelEncoder to label_encoder.pkl, so that any future inference script can invert the label encoding back to original gesture names. The LSTM model, regardless of its rank, is saved to lstm_gesture_model.h5 so it can be loaded in the future (for example, if it turned out to be the best or for further training). 

# All critical steps are commented in the code for clarity. The entire process should run in 10–15 minutes on a CPU, given the moderate dataset size and the use of early stopping and efficient algorithms. The final output is a single Python script that can be run in VS Code or any Python environment, which will train the models, output evaluation metrics, and save the necessary model files.

# ## Complete Script

# python
# Hand Gesture Recognition Training Script
# ---------------------------------------
# This script trains an LSTM model and multiple classical ML models on hand gesture sequence data.
# It evaluates their performance and saves the best model, along with the label encoder and LSTM model file.

# Configuration
import os
DATA_DIR = "D:/ROBOFLOWLSTMYOLO"         # Base directory for the CSV files
TRAIN_CSV = os.path.join(DATA_DIR, "D:/ROBOFLOWLSTMYOLO/train_seq.csv")
VALID_CSV = os.path.join(DATA_DIR, "D:/ROBOFLOWLSTMYOLO/valid_seq.csv")
TEST_CSV  = os.path.join(DATA_DIR, "D:/ROBOFLOWLSTMYOLO/test_seq.csv")
# Output model file paths
BEST_MODEL_PATH = "best_model.pkl"
LABEL_ENCODER_PATH = "label_encoder.pkl"
LSTM_MODEL_PATH = "lstm_gesture_model.h5"

# Imports
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
# Attempt to import XGBoost; if not installed, we will handle accordingly
xgb_installed = True
try:
    from xgboost import XGBClassifier
except ImportError:
    xgb_installed = False
    XGBClassifier = None

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# For LSTM model
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Masking, LSTM, Dropout, Dense
from tensorflow.keras.callbacks import EarlyStopping

# Progress bar
from tqdm import tqdm
try:
    # Use TqdmCallback for Keras if available for per-epoch progress
    from tqdm.keras import TqdmCallback
    tqdm_callback = TqdmCallback(verbose=1)
except ImportError:
    tqdm_callback = None

# 1. Load the datasets
print("Loading datasets...")
train_df = pd.read_csv(TRAIN_CSV)
valid_df = pd.read_csv(VALID_CSV)
test_df  = pd.read_csv(TEST_CSV)

# Separate features and labels
X_train = train_df.iloc[:, :-1].values   # all feature columns
y_train = train_df.iloc[:, -1].values    # label column
X_valid = valid_df.iloc[:, :-1].values
y_valid = valid_df.iloc[:, -1].values
X_test  = test_df.iloc[:, :-1].values
y_test  = test_df.iloc[:, -1].values

# 2. Encode labels to integers for consistency
print("Encoding labels...")
label_encoder = LabelEncoder()
# Fit on training labels and transform all label sets
y_train_enc = label_encoder.fit_transform(y_train)
y_valid_enc = label_encoder.transform(y_valid)
y_test_enc  = label_encoder.transform(y_test)

# Save the label encoder for future use
import pickle
with open(LABEL_ENCODER_PATH, "wb") as f:
    pickle.dump(label_encoder, f)

# 3. Reshape feature vectors into sequences for LSTM
# Each sample has 1680 features representing 40 frames * 42 features per frame.
# We reshape to (num_samples, 40, 42) for LSTM input.
X_train_seq = X_train.reshape(len(X_train), 40, 42)
X_valid_seq = X_valid.reshape(len(X_valid), 40, 42)
X_test_seq  = X_test.reshape(len(X_test), 40, 42)

# 4. Build the LSTM model
print("Building LSTM model...")
num_classes = len(label_encoder.classes_)
model = Sequential([
    # Masking layer to ignore padded timesteps (all features = 0.0 will be skipped)
    Masking(mask_value=0.0, input_shape=(40, 42)),
    # LSTM layer: using 64 units (can be adjusted), return final output only
    LSTM(64, activation='tanh'),  # using default tanh activation for LSTM
    # Dropout layer for regularization (drop 50% of units)
    Dropout(0.5),
    # Output layer with softmax for multi-class classification
    Dense(num_classes, activation='softmax')
])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()  # print model architecture summary (optional)

# 5. Train the LSTM model with EarlyStopping
print("Training LSTM model...")
callbacks = [EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)]
if tqdm_callback:
    # If TqdmCallback is available, include it to show progress bar for epochs
    callbacks.append(tqdm_callback)
# Fit the model on training data with validation
history = model.fit(
    X_train_seq, y_train_enc,
    validation_data=(X_valid_seq, y_valid_enc),
    epochs=50,  # maximum epochs (early stopping will halt earlier if no improvement)
    batch_size=32,  # small batch size for CPU
    callbacks=callbacks,
    verbose=0 if tqdm_callback else 1  # if using tqdm callback, set verbose to 0 to avoid double output
)

# After training, save the LSTM model to file (HDF5 format)
model.save(LSTM_MODEL_PATH)

# 6. Evaluate the LSTM model on the test set
y_pred_prob = model.predict(X_test_seq)              # predict class probabilities
y_pred_lstm = np.argmax(y_pred_prob, axis=1)         # predicted class indices
acc_lstm = accuracy_score(y_test_enc, y_pred_lstm)
prec_lstm = precision_score(y_test_enc, y_pred_lstm, average='macro')
rec_lstm = recall_score(y_test_enc, y_pred_lstm, average='macro')
f1_lstm = f1_score(y_test_enc, y_pred_lstm, average='macro')

# 7. Train classical ML models
print("Training classical machine learning models...")
classical_models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, solver='lbfgs', multi_class='auto'),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(n_estimators=100),
    "SVC (Linear)": SVC(kernel='linear'),  # linear kernel for speed with multi-class
    "KNN": KNeighborsClassifier(n_neighbors=5),
}
if xgb_installed:
    classical_models["XGBoost"] = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss')
else:
    print("Warning: XGBoost not installed, skipping XGBoost model.")
# Fit each model on the training data
classical_results = {}  # to store metrics for each model
for name, clf in tqdm(classical_models.items(), desc="Models"):
    try:
        clf.fit(X_train, y_train_enc)
    except Exception as e:
        print(f"Failed to train {name}: {e}")
        continue
    # Predict on test set
    y_pred = clf.predict(X_test)
    # Compute metrics
    acc = accuracy_score(y_test_enc, y_pred)
    prec = precision_score(y_test_enc, y_pred, average='macro')
    rec = recall_score(y_test_enc, y_pred, average='macro')
    f1 = f1_score(y_test_enc, y_pred, average='macro')
    classical_results[name] = (acc, prec, rec, f1)

# Also include LSTM in results for comparison
classical_results["LSTM"] = (acc_lstm, prec_lstm, rec_lstm, f1_lstm)

# 8. Print evaluation table for all models
print("\nEvaluation Results (Test Set):")
print("{:<20} {:>9} {:>9} {:>9} {:>9}".format("Model", "Accuracy", "Precision", "Recall", "F1-score"))
print("-" * 60)
for model_name, metrics in classical_results.items():
    acc, prec, rec, f1_val = metrics
    print("{:<20} {:>9.4f} {:>9.4f} {:>9.4f} {:>9.4f}".format(model_name, acc, prec, rec, f1_val))

# 9. Identify the best model based on macro F1-score
best_model_name = None
best_f1 = -1.0
for model_name, metrics in classical_results.items():
    _, _, _, f1_val = metrics
    if f1_val > best_f1:
        best_f1 = f1_val
        best_model_name = model_name

print(f"\nBest model: {best_model_name} (Macro F1 = {best_f1:.4f})")

# 10. Save the best model to disk
if best_model_name == "LSTM":
    # If the best model is the LSTM, we have already saved it as .h5.
    # Still, we can save the model architecture and weights to pickle if needed (not typical for Keras).
    with open(BEST_MODEL_PATH, "wb") as f:
        try:
            pickle.dump(model, f)
        except Exception as e:
            print("Note: Could not pickle LSTM model object, use the .h5 file for the LSTM model.")
else:
    # Save the scikit-learn model object
    best_model_obj = classical_models[best_model_name] if best_model_name in classical_models else None
    if best_model_obj is not None:
        with open(BEST_MODEL_PATH, "wb") as f:
            pickle.dump(best_model_obj, f)
    else:
        print("Best model not found in classical models dictionary; skipping saving best_model.pkl.")

print("Model training and evaluation complete. Models saved to disk.")
 

# In this script, we load the data and encode labels (ensuring the encoder is saved for consistent decoding later). We construct an LSTM model with a Masking layer so that any padded frames (all-zero vectors) are ignored during training ([Masking layer](https://keras.io/api/layers/core_layers/masking/#::text=Masks%20a%20sequence%20by%20using,mask%20value%20to%20skip%20timesteps)). A dropout layer is used to regularize the network and reduce overfitting ([  5 Techniques to Prevent Overfitting in Neural Networks - KDnuggets](https://www.kdnuggets.com/2019/12/5-techniques-prevent-overfitting-neural-networks.html#::text=Dropout%20is%20a%20regularization%20technique,and%20L2%20reduce%20overfitting%20by)) ([  5 Techniques to Prevent Overfitting in Neural Networks - KDnuggets](https://www.kdnuggets.com/2019/12/5-techniques-prevent-overfitting-neural-networks.html#::text=different%20ways%2C%20so%20the%20net,will%20be%20to%20reduce%20overfitting)). We utilize the EarlyStopping callback to stop training once the validation loss stops improving, avoiding wasted epochs and overfitting ([Overfit and underfit  |  TensorFlow Core](https://www.tensorflow.org/tutorials/keras/overfit_and_underfit#::text=Next%20include%20tf,difference%20will%20be%20important%20later)). We also integrate a tqdm progress bar for the training loop to visualize training progress ([TensorFlow Addons Callbacks: TQDM Progress Bar](https://www.tensorflow.org/addons/tutorials/tqdm_progress_bar#:~:text=Default%20TQDMCallback%20Usage)). 

# For classical models, we train each and compute their performance. The use of a linear kernel for SVC is a practical choice to ensure training completes in reasonable time on a CPU, given the multi-class nature (one-vs-rest SVM with linear kernel is far more efficient than one-vs-one with RBF for 80 classes). We then calculate accuracy, precision, recall, and F1-score (macro-averaged) for each model on the test set. The results are printed in a formatted table for easy comparison. Finally, the model with the highest macro F1-score ([  Micro, Macro & Weighted Averages of F1 Score, Clearly Explained - KDnuggets](https://www.kdnuggets.com/2023/01/micro-macro-weighted-averages-f1-score-clearly-explained.html#:~:text=The%20macro,class%20F1%20scores)) is identified as the best. We save this best model to best_model.pkl (using Python pickle, as is common for scikit-learn models ([9. Model persistence — scikit-learn 1.4.2 documentation](https://scikit-learn.org/1.4/model_persistence.html#:~:text=9.%20Model%20persistence%20%E2%80%94%20scikit,in%20persistence%20model%2C%20namely%20pickle))) and always save the LSTM model to lstm_gesture_model.h5 (the recommended format for Keras models). The label encoder is saved to allow translating predictions back to original labels in the future. 

# This comprehensive script provides an end-to-end solution for training and evaluating multiple models for gesture recognition, with clear outputs and saved artifacts for deployment or further analysis.