# Below is a *single inference script* that loads your saved artifacts (lstm_gesture_model.h5, best_model.pkl, scaler.pkl, label_encoder.pkl), opens the webcam, streams MediaPipe hand‑landmarks, maintains a rolling window of the *latest 40 frames*, and prints / overlays the predicted word in real time.

# ---

# ## How it works — at a glance

# | Step | What happens | Why it matters |
# |------|--------------|----------------|
# | 1 ⃣ | *MediaPipe Hands* (tracking mode) detects up to one hand each frame and outputs 21 (x,y) key‑points. | Much faster than static image mode and robust for video. |
# | 2 ⃣ | A deque(maxlen=40) stores the most recent *40 landmark frames*. Missing frames are auto‑padded with zeros. | Keeps constant sequence length expected by your LSTM. |
# | 3 ⃣ | Every frame we: <br/>• reshape buffer → (1, 40, 42) for LSTM <br/>• flatten → (1, 1680) + scale for classical model | Lets you compare both models live if you wish. |
# | 4 ⃣ | Use Masking built into the LSTM model to ignore padded all‑zero rows. | Zeros won’t hurt prediction. |
# | 5 ⃣ | Display predicted label and confidence on‑screen; red *“Close”* button or Esc quits cleanly. | User‑friendly exit, avoids freeze. |

# ---

# ## live_inference.py

# python
"""
live_inference.py    Realtime signword detection with MediaPipe + LSTM (and SVC)

Requirements
------------
pip install opencv-python mediapipe tensorflow scikit-learn numpy tqdm

Files expected (same folder or give absolute paths):
    lstm_gesture_model.h5    trained Keras model
    best_model.pkl           best classical model (e.g. SVC) from train script
    scaler.pkl               StandardScaler fitted on training data
    label_encoder.pkl        LabelEncoder mapping ints ↔ words
"""

import cv2, time, pickle, numpy as np
from collections import deque
from tensorflow.keras.models import load_model
import mediapipe as mp
from tqdm import tqdm

# ---------- CONFIG ----------------------------------------------------------
SEQ_LEN   = 40      # must match training
FEATURES  = 42      # 21 landmarks × (x,y)
CONF_SHOW = True    # display softmax confidence for LSTM
USE_SVC   = False   # set True if you also want SVC predictions
# Paths (edit if needed)
LSTM_PATH   = r"C:/Users/singh/Documents/.vscode/Minor - 2/Words_MP/model/lstm_gesture_model.h5"
LABEL_ENC   = r"C:/Users/singh/Documents/.vscode/Minor - 2/Words_MP/model/label_encoder.pkl"
# SCALER_PATH = r"/:\ROBOFLOWLSTMYO/O\models\scaler.pkl"
SVC_PATH    = r"C:/Users/singh/Documents/.vscode/Minor - 2/Words_MP/model/best_model.pkl"
# ---------------------------------------------------------------------------

print("Loading models ...")
lstm_model = load_model(LSTM_PATH)
with open(LABEL_ENC, "rb") as f:
    le = pickle.load(f)
# if USE_SVC:
#     with open(SCALER_PATH, "rb") as f:
#         scaler = pickle.load(f)
#     with open(SVC_PATH, "rb") as f:
#         svc = pickle.load(f)

print("Models loaded. Opening webcam ...")
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("Could not open webcam.")

# MediaPipe Hands – video (tracking) mode
mp_hands = mp.solutions.hands
mp_draw  = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    static_image_mode=False,       # tracking mode
    max_num_hands=1,
    model_complexity=0,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.3
)

# Rolling buffer for 40 frames
buffer = deque(maxlen=SEQ_LEN)

exit_flag = False
cv2.namedWindow("GestureDetector")

def click_event(event, x, y, flags, param):
    global exit_flag
    if event == cv2.EVENT_LBUTTONDOWN and 10 <= x <= 110 and 10 <= y <= 50:
        exit_flag = True

cv2.setMouseCallback("GestureDetector", click_event)

fps_time = time.time()
while cap.isOpened() and not exit_flag:
    ret, frame = cap.read()
    if not ret: break
    frame = cv2.flip(frame, 1)
    rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    res = hands.process(rgb)

    # Default zero vector (padding frame)
    landmarks_2d = [0.0] * (FEATURES)
    if res.multi_hand_landmarks:
        hand = res.multi_hand_landmarks[0]
        # draw landmarks
        mp_draw.draw_landmarks(frame, hand, mp_hands.HAND_CONNECTIONS)
        # extract normalized x,y
        coords = []
        for lm in hand.landmark:
            coords.extend([lm.x, lm.y])
        landmarks_2d = coords

    buffer.append(landmarks_2d)

    # Only predict if we have SEQ_LEN frames collected
    if len(buffer) == SEQ_LEN:
        seq_array = np.array(buffer).reshape(1, SEQ_LEN, FEATURES)
        # ----- LSTM prediction -----
        softmax = lstm_model.predict(seq_array, verbose=0)[0]
        lstm_idx = int(np.argmax(softmax))
        lstm_label = le.inverse_transform([lstm_idx])[0]
        lstm_conf  = float(np.max(softmax))

        display_text = f"LSTM: {lstm_label}"
        if CONF_SHOW:
            display_text += f" ({lstm_conf:.2f})"

        # ----- Optional SVC prediction -----
        # if USE_SVC:
        #     flat = seq_array.reshape(1, -1)
        #     flat_scaled = scaler.transform(flat)
        #     svc_idx = int(svc.predict(flat_scaled)[0])
        #     svc_label = le.inverse_transform([svc_idx])[0]
        #     display_text += f"  |SVC: {svc_label}"

        # put text on frame
        cv2.putText(frame, display_text, (20, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

    # "Close" button
    cv2.rectangle(frame, (10,10), (110,50), (0,0,255), -1)
    cv2.putText(frame, "Close", (25,40),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

    # fps overlay
    fps = 1/(time.time()-fps_time)
    fps_time = time.time()
    cv2.putText(frame, f"FPS: {fps:.1f}", (500,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,0), 2)

    cv2.imshow("GestureDetector", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # Esc
        break

cap.release()
cv2.destroyAllWindows()
hands.close()
print("Session ended.")


### Where to put your files


# D:/ROBOFLOWLSTMYOLO/
# ├── models/
# │   ├── lstm_gesture_model.h5
# │   ├── label_encoder.pkl
# │   ├── scaler.pkl
# │   └── best_model.pkl
# └── live_inference.py   ← place script here (or edit paths)




## Key details

# | Detail | Why / Fix |
# |--------|-----------|
# | *Masking works at inference, too* | The Masking layer is baked into the saved .h5; padded zeros remain harmless. |
# | *Freeze / lag* | Using tracking mode (static_image_mode=False) and drawing once per frame keeps FPS high; update rate shown top‑left. |
# | *Clean exit* | Red “Close” button (mouse) *or* Esc key sets exit_flag → clean release of camera & windows. |
# | *Confidence* | Highest softmax score is shown; toggle with CONF_SHOW. |
# | *Classical model optional* | Set USE_SVC = True if you want side‑by‑side SVC predictions (requires scaler.pkl, best_model.pkl). |

# This script should run smoothly on your CPU‑only VS Code setup.  
# Once you’re happy with predictions, you can package these files for deployment or integrate into a larger application. Good luck—have fun signing!
