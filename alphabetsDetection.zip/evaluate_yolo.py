from ultralytics import YOLO
import os

def evaluate_model(model_path="best.pt"):
    try:
        model = YOLO(model_path)
        print("Model loaded.")
        
        # Run validation (ensure your data.yaml was used during training)
        metrics = model.val()

        # Check if validation output directory exists
        run_dir = "runs/detect/val"
        if not os.path.exists(run_dir):
            print("\n⚠️ No validation directory found. Ensure your model was trained with a valid dataset.")
            return

        last_run_dir = sorted(os.listdir(run_dir))[-1]
        full_path = os.path.abspath(os.path.join(run_dir, last_run_dir))

        print("\n✅ Evaluation complete!")
        print("📊 Plots saved to:", full_path)

        # Print some key metrics
        print("\n--- Key Metrics ---")
        print(f"Precision: {metrics.box.precision:.4f}")
        print(f"Recall:    {metrics.box.recall:.4f}")
        print(f"F1 Score:  {metrics.box.f1:.4f}")
        print(f"mAP@0.5:   {metrics.box.map50:.4f}")
        print(f"mAP@0.5:0.95: {metrics.box.map:.4f}")

    except Exception as e:
        print(f"\n❌ Error during evaluation: {e}")

if __name__ == "__main__":
    evaluate_model("best.pt")
